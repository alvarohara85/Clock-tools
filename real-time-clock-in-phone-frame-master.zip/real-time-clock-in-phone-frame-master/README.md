Html Css Javascript Real Time Clock Premium Design

Demo : https://wafarifki.github.io/real-time-clock-in-phone-frame/
